for i=1:298
    g(i)=i;
end

fileID = fopen('exp.txt','w');
fprintf(fileID,'%2.f, ',g,',');
fclose(fileID);